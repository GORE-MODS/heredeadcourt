﻿using ExitGames.Client.Photon;
using Photon.Pun;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace StupidTemplate.Classes
{
    internal class CustomProperty
    {
        public static void Gorecusp()
        {
            Gore["GORE.Win"] = "easports";
            PhotonNetwork.SetPlayerCustomProperties(Gore);
        }
        private static ExitGames.Client.Photon.Hashtable Gore = PhotonNetwork.LocalPlayer.CustomProperties;
    }
}