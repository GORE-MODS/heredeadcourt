﻿using GorillaLocomotion;
using GorillaNetworking;
using Photon.Pun;
using StupidTemplate.Classes;
using StupidTemplate.Mods;
using StupidTemplate.Notifications;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;
using System.Text;
using UnityEngine;
using static StupidTemplate.Menu.Main;
using static StupidTemplate.Settings;

namespace StupidTemplate.Mods
{
    public class Safety
    {
        public static void AntiReport()
        {
            if (PhotonNetwork.InRoom)
            {
                foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                {
                    if (vrrig != GorillaTagger.Instance.offlineVRRig)
                    {
                        Vector3 rHand = vrrig.rightHandTransform.position;
                        Vector3 lHand = vrrig.leftHandTransform.position;
                        rHand = vrrig.rightHandTransform.position + vrrig.rightHandTransform.forward * 0.125f;
                        lHand = vrrig.leftHandTransform.position + vrrig.leftHandTransform.forward * 0.125f;
                        float range = 0.6f;
                        foreach (GorillaPlayerScoreboardLine gorillaPlayerScoreboardLine in GorillaScoreboardTotalUpdater.allScoreboardLines)
                        {
                            if (gorillaPlayerScoreboardLine.linePlayer == NetworkSystem.Instance.LocalPlayer)
                            {
                                Vector3 reportButton = gorillaPlayerScoreboardLine.reportButton.gameObject.transform.position + new Vector3(0f, 0.001f, 0.0004f);
                                if (Vector3.Distance(reportButton, lHand) < range)
                                {
                                    NotifiLib.SendNotification("<color=red>Anti-Report:</color> : " + vrrig.playerText1.text + " Attempted to Report You");
                                    NetworkSystem.Instance.ReturnToSinglePlayer();
                                }
                                if (Vector3.Distance(reportButton, rHand) < range)
                                {
                                    NotifiLib.SendNotification("<color=red>Anti-Report</color> : " + vrrig.playerText1.text + " Attempted to <color=red>Report</color> You");
                                    NetworkSystem.Instance.ReturnToSinglePlayer();
                                }
                            }
                        }
                    }
                }
            }
        }
        public static void ReturnTostump()
        {

            Vector3 targetPosition = new Vector3(-66.9039f, 11.8661f, -82.1227f);
            Quaternion targetRotation = Quaternion.identity;
            GTPlayer.Instance.TeleportTo(targetPosition, targetRotation);
        }

        public static void AntiAfk()
        {
            PhotonNetworkController.Instance.disableAFKKick = true;
        }
        public static void NoFinger()
        {
            ControllerInputPoller.instance.leftControllerGripFloat = 0f;
            ControllerInputPoller.instance.rightControllerGripFloat = 0f;
            ControllerInputPoller.instance.leftControllerIndexFloat = 0f;
            ControllerInputPoller.instance.rightControllerIndexFloat = 0f;
            ControllerInputPoller.instance.leftControllerPrimaryButton = false;
            ControllerInputPoller.instance.leftControllerSecondaryButton = false;
            ControllerInputPoller.instance.rightControllerPrimaryButton = false;
            ControllerInputPoller.instance.rightControllerSecondaryButton = false;
            ControllerInputPoller.instance.leftControllerPrimaryButtonTouch = false;
            ControllerInputPoller.instance.leftControllerSecondaryButtonTouch = false;
            ControllerInputPoller.instance.rightControllerPrimaryButtonTouch = false;
            ControllerInputPoller.instance.rightControllerSecondaryButtonTouch = false;
        }
        public static void MasterCheck()
        {
            bool isMasterClient = NetworkSystem.Instance.IsMasterClient;
            if (isMasterClient)
            {
                NotifiLib.SendNotification("<color=grey>[</color><color=green>SUCCESS</color><color=grey>]</color> <color=white>Yes, you are master client.</color>");
            }
            else
            {
                NotifiLib.SendNotification("<color=grey>[</color><color=red>ERROR</color><color=grey>]</color> <color=white>No, you are not master client.</color>");
            }
        }
    }
}
