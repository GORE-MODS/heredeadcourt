﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;
using System.Text;
using UnityEngine;

namespace StupidTemplate.Mods
{
    public class Game
    {
        public static void Exit()
        {
            Application.Quit();
        }
    }
}
