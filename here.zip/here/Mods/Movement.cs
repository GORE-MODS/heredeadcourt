﻿using BepInEx;
using ExitGames.Client.Photon;
using GorillaLocomotion;
using Photon.Pun;
using Photon.Realtime;
using StupidTemplate.Classes;
using UnityEngine;
using UnityEngine.XR;
using static StupidTemplate.Menu.Main;

namespace StupidTemplate.Mods
{
    public class Movement
    {
        public static void Fly()
        {
            if (ControllerInputPoller.instance.rightControllerPrimaryButton)
            {
                GTPlayer.Instance.transform.position += GorillaTagger.Instance.headCollider.transform.forward * Time.deltaTime * Settings.Movement.flySpeed;
                GorillaTagger.Instance.rigidbody.linearVelocity = Vector3.zero;
            }
        }

        public static void TriggerFly()
        {
            if (ControllerInputPoller.instance.rightControllerTriggerButton)
            {
                GTPlayer.Instance.transform.position += GorillaTagger.Instance.headCollider.transform.forward * Time.deltaTime * Settings.Movement.flySpeed;
                GorillaTagger.Instance.rigidbody.linearVelocity = Vector3.zero;
            }
        }

        public static void HandFly()
        {
            if (ControllerInputPoller.instance.rightControllerPrimaryButton)
            {
                GTPlayer.Instance.transform.position += TrueRightHand().forward * (Time.deltaTime * Settings.Movement.flySpeed);
                GorillaTagger.Instance.rigidbody.linearVelocity = Vector3.zero;
            }
        }

        private static GameObject leftplat = null;
        private static GameObject rightplat = null;

        private static GameObject CreatePlatformOnHand(Transform handTransform)
        {
            GameObject plat = GameObject.CreatePrimitive(PrimitiveType.Cube);
            plat.transform.localScale = new Vector3(0.025f, 0.3f, 0.4f);

            plat.transform.position = handTransform.position;
            plat.transform.rotation = handTransform.rotation;

            float h = (Time.frameCount / 180f) % 1f;
            plat.GetComponent<Renderer>().material.color = ColorLib.RedTransparent;
            return plat;
        }

        public static void Platforms()
        {
            bool rightGrab = ControllerInputPoller.instance.rightGrab;
            bool leftGrab = ControllerInputPoller.instance.leftGrab;
            bool leftgriprel = ControllerInputPoller.instance.leftGrabRelease;
            bool rightgriprel = ControllerInputPoller.instance.rightGrabRelease;
            if (leftGrab && leftplat == null)
            {
                leftplat = CreatePlatformOnHand(GorillaTagger.Instance.leftHandTransform);
            }

            if (rightGrab && rightplat == null)
            {
                rightplat = CreatePlatformOnHand(GorillaTagger.Instance.rightHandTransform);
            }

            if (rightgriprel && rightplat != null)
            {
                rightplat.Disable();
                rightplat = null;
            }

            if (leftgriprel && leftplat != null)
            {
                leftplat.Disable();
                leftplat = null;
            }
        }
        public static void Noclip()
        {
            bool NoCollide = ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f;
            MeshCollider[] colliders = Resources.FindObjectsOfTypeAll<MeshCollider>();

            foreach (MeshCollider collider in colliders)
            {
                collider.enabled = !NoCollide;
            }
        }
        public static void EnableSteamLongArms()
        {
            GorillaLocomotion.GTPlayer.Instance.transform.localScale = new Vector3(1.25f, 1.25f, 1.25f);
        }

        public static void DisableSteamLongArms()
        {
            GTPlayer.Instance.transform.localScale = Vector3.one;
        }
        public static void FlickJumpting()
        {
            bool rightprib = ControllerInputPoller.instance.rightControllerPrimaryButton;
            if (rightprib)
                GTPlayer.Instance.rightHand.controllerTransform.position = GorillaTagger.Instance.rightHandTransform.position + new Vector3(0f, -1.5f, 0f);
        }
        public static void BunnyHop()
        {
            Physics.Raycast(GorillaTagger.Instance.bodyCollider.transform.position - new Vector3(0f, 0.2f, 0f), Vector3.down, out var Ray, 512f, GTPlayer.Instance.locomotionEnabledLayers);

            if (Ray.distance < 0.15f)
                GorillaTagger.Instance.rigidbody.linearVelocity = new Vector3(GorillaTagger.Instance.rigidbody.linearVelocity.x, GTPlayer.Instance.jumpMultiplier * 2.727272727f, GorillaTagger.Instance.rigidbody.linearVelocity.z);
        }

        public static void GripFly()
        {
            bool rightGrab = ControllerInputPoller.instance.rightGrab;
            if (rightGrab)
            {
                GTPlayer.Instance.transform.position += GorillaTagger.Instance.headCollider.transform.forward * Time.deltaTime * Settings.Movement.flySpeed;
                GorillaTagger.Instance.rigidbody.linearVelocity = Vector3.zero;
            }
        }
        public static void GripHandFly()
        {
            bool rightGrab = ControllerInputPoller.instance.rightGrab;
            if (rightGrab)
            {
                GTPlayer.Instance.transform.position += TrueRightHand().forward * (Time.deltaTime * Settings.Movement.flySpeed);
                GorillaTagger.Instance.rigidbody.linearVelocity = Vector3.zero;
            }
        }
        
        public static void TPGun()
        {
            GunTemplate.StartBothGuns(() =>
            {
                GTPlayer.Instance.transform.position = GunTemplate.spherepointer.transform.position;
                GorillaTagger.Instance.transform.position = GunTemplate.spherepointer.transform.position;
                GameObject.Destroy(GunTemplate.spherepointer, Time.deltaTime);
            }, false);
        }
        public static void NoTagFreeze()
        {
            GTPlayer.Instance.disableMovement = false;
        }
        public static void AirStrike()
        {
            GunTemplate.StartBothGuns(() =>
            {
                GTPlayer.Instance.transform.position = GunTemplate.spherepointer.transform.position + new Vector3(0f, 20f, 0f);
                GorillaTagger.Instance.transform.position = GunTemplate.spherepointer.transform.position + new Vector3(0f, 20f, 0f);
                GameObject.Destroy(GunTemplate.spherepointer, Time.deltaTime);
            }, false);
        }
        public static void CarMonkey()
        {
            Vector3 forward = GTPlayer.Instance.headCollider.transform.forward;
            forward.y = 0;
            forward.Normalize();

            if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.2f)
            {
                GTPlayer.Instance.transform.position += forward * Time.deltaTime * 25;
                GTPlayer.Instance.GetComponent<Rigidbody>().linearVelocity = Vector3.zero;
            }
            if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.2f)
            {
                GTPlayer.Instance.transform.position -= forward * Time.deltaTime * 25;
                GTPlayer.Instance.GetComponent<Rigidbody>().linearVelocity = Vector3.zero;
            }
        }
        public static void Speedboost()
        {
            GTPlayer.Instance.maxJumpSpeed = 8f;
            GTPlayer.Instance.jumpMultiplier = 8f;
        }
        public static void TPToRandom()
        {
            GTPlayer.Instance.transform.position = RigManager.GetRandomVRRig(false).transform.position;
            GTPlayer.Instance.GetComponent<Rigidbody>().linearVelocity = Vector3.zero;
        }

        public static void PlatGun()
        {
            GunTemplate.StartBothGuns(() =>
            {
                GameObject platg = GameObject.CreatePrimitive(PrimitiveType.Cube);
                Object.Destroy(platg.GetComponent<BoxCollider>());
                platg.GetComponent<Renderer>().material.color = ColorLib.Red;
                platg.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
                platg.transform.localScale = new Vector3(0.025f, 0.3f, 0.4f);
                platg.transform.position = GunTemplate.spherepointer.transform.position;
                platg.transform.rotation = Quaternion.Euler(UnityEngine.Random.Range(0, 360), UnityEngine.Random.Range(0, 360), UnityEngine.Random.Range(0, 360));
                Object.Destroy(platg, 1f);
                GameObject.Destroy(GunTemplate.spherepointer, Time.deltaTime);
            }, false);
        }
        public static void SpGun()
        {
            GunTemplate.StartBothGuns(() =>
            {
                GameObject platg = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                Object.Destroy(platg.GetComponent<SphereCollider>());
                platg.GetComponent<Renderer>().material.color = ColorLib.Red;
                platg.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
                platg.transform.localScale = new Vector3(0.025f, 0.3f, 0.4f);
                platg.transform.position = GunTemplate.spherepointer.transform.position;
                Object.Destroy(platg, 1f);
                GameObject.Destroy(GunTemplate.spherepointer, Time.deltaTime);
            }, false);
        }
        public static void Frozone()
        {
            bool leftgrab = ControllerInputPoller.instance.leftGrab;
            bool rightgrab = ControllerInputPoller.instance.rightGrab;
            if (leftgrab)
            {
                GameObject REEYDU = GameObject.CreatePrimitive(PrimitiveType.Cube);
                REEYDU.GetComponent<Renderer>().material.color = ColorLib.RedTransparent;
                REEYDU.transform.localScale = new Vector3(0.025f, 0.3f, 0.4f);
                REEYDU.transform.localPosition = TrueLeftHand().position + TrueLeftHand().right * 0.05f;
                REEYDU.transform.rotation = TrueLeftHand().rotation;

                REEYDU.AddComponent<GorillaSurfaceOverride>().overrideIndex = 61;
                Object.Destroy(REEYDU, 1);
            }

            if (rightgrab)
            {
                GameObject REEYDU = GameObject.CreatePrimitive(PrimitiveType.Cube);
                REEYDU.GetComponent<Renderer>().material.color = ColorLib.RedTransparent;
                REEYDU.transform.localScale = new Vector3(0.025f, 0.3f, 0.4f);
                REEYDU.transform.localPosition = TrueRightHand().position + TrueRightHand().right * -0.05f;
                REEYDU.transform.rotation = TrueRightHand().rotation;

                REEYDU.AddComponent<GorillaSurfaceOverride>().overrideIndex = 61;
                Object.Destroy(REEYDU, 1);
            }

            GorillaTagger.Instance.bodyCollider.enabled = !(leftgrab || rightgrab);
        }
        public static void SlingshotFly()
        {
            bool rightPrimary = ControllerInputPoller.instance.rightControllerPrimaryButton;
            if (rightPrimary)
                GorillaTagger.Instance.rigidbody.linearVelocity += GTPlayer.Instance.headCollider.transform.forward * (Time.deltaTime * (StupidTemplate.Mods.Settings.Movement.flySpeed));
        }
        public static void LowGravity() =>
            GorillaTagger.Instance.rigidbody.AddForce(Vector3.up * 6.66f, ForceMode.Acceleration);

        public static void ZeroGravity() =>
            GorillaTagger.Instance.rigidbody.AddForce(-Physics.gravity, ForceMode.Acceleration);

        public static void HighGravity() =>
            GorillaTagger.Instance.rigidbody.AddForce(Vector3.down * 7.77f, ForceMode.Acceleration);

        public static void ReverseGravity()
        {
            GorillaTagger.Instance.rigidbody.AddForce(Vector3.up * 19.62f, ForceMode.Acceleration);
            GTPlayer.Instance.GetControllerTransform(false).parent.rotation = Quaternion.Euler(180f, 0f, 0f);
        }
    }
}