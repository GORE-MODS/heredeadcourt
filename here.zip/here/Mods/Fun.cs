﻿using System;
using System.Collections.Generic;
using GorillaLocomotion;
using Photon.Pun;
using Photon.Voice.Unity;
using Photon.Voice.Unity.UtilityScripts;
using StupidTemplate.Menu;
using StupidTemplate.Patches;
using UnityEngine;

namespace StupidTemplate.Mods
{
    public class Fun
    {
        public static void CopySelfID()
        {
            string id = PhotonNetwork.LocalPlayer.UserId;
            GUIUtility.systemCopyBuffer = id;
        }
    }
}