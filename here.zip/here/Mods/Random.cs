﻿using StupidTemplate.Menu;
using StupidTemplate.Notifications;
using UnityEngine;

namespace StupidTemplate.Mods
{
    public class Random
    {
        public static void NotificationSpam()
        {
            NotifiLib.SendNotification("SPAMMMMM");
            NotifiLib.SendNotification("SPAMMMMM");
            NotifiLib.SendNotification("SPAMMMMM");
            NotifiLib.SendNotification("SPAMMMMM");
            NotifiLib.SendNotification("SPAMMMMM");
            NotifiLib.SendNotification("SPAMMMMM");
            NotifiLib.SendNotification("SPAMMMMM");
        }

        public static void Checkifadmin()
        {
            if (AdminLIB.AdminLIB.IsAdmin)
            {
                NotifiLib.SendNotification("<color=Green>[AdminLIB]</color>  Your a admin!!!!!!");
            }
            else
            {
                NotifiLib.SendNotification("<color=Red>[AdminLIB]</color>  Your not a admin");
            }
        }
    }
}
