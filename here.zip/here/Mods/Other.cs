﻿using GorillaLocomotion;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using System.Threading;
using UnityEngine;

namespace StupidTemplate.Mods
{
    internal class Other
    {
        public static void Joindc()
        {
            Process.Start(serverlink);
        }
        public static string serverlink = "https://discord.gg/pvt3hgqfEb";
    }
}
