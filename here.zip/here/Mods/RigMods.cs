﻿using BepInEx;
using GorillaLocomotion;
using StupidTemplate.Classes;
using System;
using System.Collections.Generic;
using System.Numerics;
using System.Text;
using Unity.Mathematics;
using UnityEngine;
using UnityEngine.InputSystem;

namespace StupidTemplate.Mods
{
    internal class RigMods
    {
        public static void ghost()
        {
            bool rightpri = ControllerInputPoller.instance.rightControllerPrimaryButton;
            if (rightpri)
            {
                GorillaTagger.Instance.offlineVRRig.enabled = false;
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }
        }

        public static void Grabrig()
        {
            bool rightGrab = ControllerInputPoller.instance.rightGrab;
            if (rightGrab)
            {
                VRRig.LocalRig.enabled = false;

                VRRig.LocalRig.transform.position = GorillaTagger.Instance.rightHandTransform.position;

            }
            else
            {
                VRRig.LocalRig.enabled = true;
            }
        }
        public static void FixHead()
        {
            VRRig.LocalRig.head.trackingRotationOffset.x = 0f;
            VRRig.LocalRig.head.trackingRotationOffset.y = 0f;
            VRRig.LocalRig.head.trackingRotationOffset.z = 0f;
        }
        public static void UpsideDownHead()
        {
            VRRig.LocalRig.head.trackingRotationOffset.z = 180f;
        }

        public static void BrokenNeck()
        {
            VRRig.LocalRig.head.trackingRotationOffset.z = 90f;
        }

        public static void BackwardsHead()
        {
            VRRig.LocalRig.head.trackingRotationOffset.y = 180f;
        }

        public static void SidewaysHead()
        {
            VRRig.LocalRig.head.trackingRotationOffset.y = 90f;
        }
        public static void Invisible()
        {
            bool rightpri = ControllerInputPoller.instance.rightControllerPrimaryButton;
            if (rightpri)
            {
                GorillaTagger.Instance.offlineVRRig.enabled = false;
                GorillaTagger.Instance.offlineVRRig.transform.position = new UnityEngine.Vector3(0, 999, 0);
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;

            }
        }
        public static void LeftGrabrig()
        {
            bool rightGrab = ControllerInputPoller.instance.rightGrab;
            if (rightGrab)
            {
                VRRig.LocalRig.enabled = false;
                VRRig.LocalRig.transform.position = GorillaTagger.Instance.leftHandTransform.position;

            }
            else
            {
                VRRig.LocalRig.enabled = true;
            }
        }

        public static void Griddy()
        {
            bool griddyfrfr = (double)ControllerInputPoller.instance.rightControllerIndexFloat > 0.1;
            if (griddyfrfr | Mouse.current.leftButton.isPressed)
            {
                GorillaTagger.Instance.offlineVRRig.enabled = false;
                UnityEngine.Vector3 b = GorillaTagger.Instance.offlineVRRig.transform.forward * (3f * Time.deltaTime);
                GorillaTagger.Instance.offlineVRRig.transform.position += b;
                GorillaTagger.Instance.offlineVRRig.head.rigTarget.transform.rotation = GorillaTagger.Instance.offlineVRRig.transform.rotation;
                float d = 0.5f * Mathf.Cos((float)Time.frameCount / 10f);
                float d2 = -0.3f * Mathf.Abs(Mathf.Sin((float)Time.frameCount / 7f));
                UnityEngine.Vector3 b2 = GorillaTagger.Instance.offlineVRRig.transform.right * -0.25f + GorillaTagger.Instance.offlineVRRig.transform.forward * d + GorillaTagger.Instance.offlineVRRig.transform.up * d2;
                UnityEngine.Vector3 b3 = GorillaTagger.Instance.offlineVRRig.transform.right * 0.25f + GorillaTagger.Instance.offlineVRRig.transform.forward * d + GorillaTagger.Instance.offlineVRRig.transform.up * d2;
                GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget.transform.position = GorillaTagger.Instance.offlineVRRig.transform.position + b2;
                GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget.transform.position = GorillaTagger.Instance.offlineVRRig.transform.position + b3;
                GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget.transform.rotation = GorillaTagger.Instance.offlineVRRig.transform.rotation;
                GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget.transform.rotation = GorillaTagger.Instance.offlineVRRig.transform.rotation;
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }
        }

        public static void HelicopterMonke()
        {
            bool imaheli = (double)ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f | UnityInput.Current.GetKey(KeyCode.H);
            if (imaheli)
            {
                GorillaTagger.Instance.offlineVRRig.enabled = false;
                GorillaTagger.Instance.offlineVRRig.transform.position += new UnityEngine.Vector3(0f, 0.075f, 0f);
                GorillaTagger.Instance.offlineVRRig.transform.rotation = UnityEngine.Quaternion.Euler(GorillaTagger.Instance.offlineVRRig.transform.rotation.eulerAngles + new UnityEngine.Vector3(0f, 10f, 0f));
                GorillaTagger.Instance.offlineVRRig.head.rigTarget.transform.rotation = GorillaTagger.Instance.offlineVRRig.transform.rotation;
                GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget.transform.position = GorillaTagger.Instance.offlineVRRig.transform.position + GorillaTagger.Instance.offlineVRRig.transform.right * -1f;
                GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget.transform.position = GorillaTagger.Instance.offlineVRRig.transform.position + GorillaTagger.Instance.offlineVRRig.transform.right * 1f;
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }
        }
        public static void Spaz()
        {
            GorillaTagger.Instance.offlineVRRig.head.rigTarget.eulerAngles = new UnityEngine.Vector3((float)UnityEngine.Random.Range(0, 360), (float)UnityEngine.Random.Range(0, 360), (float)UnityEngine.Random.Range(0, 360));
            GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget.eulerAngles = new UnityEngine.Vector3((float)UnityEngine.Random.Range(0, 360), (float)UnityEngine.Random.Range(0, 360), (float)UnityEngine.Random.Range(0, 360));
            GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget.eulerAngles = new UnityEngine.Vector3((float)UnityEngine.Random.Range(0, 360), (float)UnityEngine.Random.Range(0, 360), (float)UnityEngine.Random.Range(0, 360));

            GorillaTagger.Instance.offlineVRRig.head.rigTarget.eulerAngles = new UnityEngine.Vector3((float)UnityEngine.Random.Range(0, 360), (float)UnityEngine.Random.Range(0, 180), (float)UnityEngine.Random.Range(0, 180));
            GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget.eulerAngles = new UnityEngine.Vector3((float)UnityEngine.Random.Range(0, 360), (float)UnityEngine.Random.Range(0, 180), (float)UnityEngine.Random.Range(0, 180));
            GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget.eulerAngles = new UnityEngine.Vector3((float)UnityEngine.Random.Range(0, 360), (float)UnityEngine.Random.Range(0, 180), (float)UnityEngine.Random.Range(0, 180));
        }
        public static void RigGun()
        {
            GunTemplate.StartBothGuns(() =>
            {
                GorillaTagger.Instance.offlineVRRig.enabled = false;
                GorillaTagger.Instance.offlineVRRig.transform.position = GunTemplate.spherepointer.transform.position + new UnityEngine.Vector3(0f, 1f, 0f);
                HandOrbs.HandOrbs1();
            }, false);
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }
        }
        public static void LookAtClosest()
        {
            if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.2f | UnityInput.Current.GetKey("T"))
            {
                GorillaTagger.Instance.offlineVRRig.headConstraint.LookAt(Close.headMesh.transform.position);
                GorillaTagger.Instance.offlineVRRig.head.rigTarget.LookAt(Close.headMesh.transform.position);
            }
        }
        public static VRRig Close = RigManager.GetClosestVRRig();

        public static UnityEngine.Vector3 Random(float dis)
        {
            UnityEngine.Vector3[] ran = new UnityEngine.Vector3[]
            {
                new UnityEngine.Vector3(dis, 0f, 0f),
                new UnityEngine.Vector3(dis, dis, 0f),
                new UnityEngine.Vector3(dis, dis, dis),
                new UnityEngine.Vector3(dis, 0f, dis),
                new UnityEngine.Vector3(0f, 0f, dis),
                new UnityEngine.Vector3(0f, dis, dis),
                new UnityEngine.Vector3(0f, dis, 0f),
                new UnityEngine.Vector3(-dis, 0f, 0f),
                new UnityEngine.Vector3(-dis, -dis, 0f),
                new UnityEngine.Vector3(-dis, -dis, -dis),
                new UnityEngine.Vector3(-dis, 0f, -dis),
                new UnityEngine.Vector3(0f, 0f, -dis),
                new UnityEngine.Vector3(0f, -dis, -dis),
                new UnityEngine.Vector3(0f, -dis, 0f),
            };
            return ran[UnityEngine.Random.Range(0, ran.Length)];
        }
        public static float delay;
        public static void DelayedAction(float time, Action action)
        {
            if (Time.time > delay)
            {
                action.Invoke();
                delay = Time.time + time;
            }
        }
        public static int fake = 1;
    
    public static void FlipHands()
        {
            UnityEngine.Vector3 position = GorillaTagger.Instance.leftHandTransform.position;
            UnityEngine.Vector3 position2 = GorillaTagger.Instance.rightHandTransform.position;
            UnityEngine.Quaternion rotation = GorillaTagger.Instance.leftHandTransform.rotation;
            UnityEngine.Quaternion rotation2 = GorillaTagger.Instance.rightHandTransform.rotation;
            GTPlayer.Instance.RightHand.controllerTransform.transform.position = position;
            GTPlayer.Instance.LeftHand.controllerTransform.transform.position = position2;
            GTPlayer.Instance.RightHand.controllerTransform.transform.rotation = rotation;
            GTPlayer.Instance.LeftHand.controllerTransform.transform.rotation = rotation2;
        }
    }
}