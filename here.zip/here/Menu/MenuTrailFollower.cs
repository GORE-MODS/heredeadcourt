﻿using UnityEngine;

namespace StupidTemplate.Menu
{
    public class MenuTrailFollower : MonoBehaviour
    {
        // hii skidders/dnspy users you are allowed to use this for your menu
        public Transform target;
        public float orbitRadius = 0.25f;
        public float orbitSpeed = 120f;
        public bool reverseDirection = false;

        private TrailRenderer tr;
        private float orbitAngle;

        void Start()
        {
            tr = GetComponent<TrailRenderer>();
            if (tr == null)
                tr = gameObject.AddComponent<TrailRenderer>();

            orbitAngle = Random.Range(0f, 360f);
        }

        void LateUpdate()
        {
            if (target == null)
            {
                if (tr != null) tr.emitting = false;
                return;
            }

            float speed = reverseDirection ? -orbitSpeed : orbitSpeed;
            orbitAngle += speed * Time.deltaTime;

            float radians = orbitAngle * Mathf.Deg2Rad;
            Vector3 offset = new Vector3(Mathf.Cos(radians), 0, Mathf.Sin(radians)) * orbitRadius;

            transform.position = target.position + target.rotation * offset;
            transform.rotation = target.rotation;
        }
    }
}
