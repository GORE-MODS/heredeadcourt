﻿using Photon.Pun;
using Photon.Realtime;
using PlayFab.ClientModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using UnityEngine;

namespace StupidTemplate.Menu
{
    /// <summary>
    /// Made by Industry. Add this to a gameobject to use it correctly. This will automatically report players.
    /// DM me player IDs to add to the list.This is made for getting people that report players in code mod/mods banned.
    /// W Industry
    /// </summary>
    internal class ARS : MonoBehaviour
    {
        public static List<Player> PlayersChecked = new List<Player>();
        public static string PlayerIDs = string.Empty;
        public static string[] PlayersToReport = new string[0];
        void Update()
        {
            if (PlayerIDs == string.Empty)
                GetPlayerIDs();

            if (PlayersToReport.Length < 3)
                GetPlayerIDs();

            if (PlayersToReport == null) return;

            foreach (Player plr in PhotonNetwork.PlayerListOthers)
            {
                if (PlayersChecked.Contains(plr)) return;

                if (NeedToReport(plr))
                {
                    GorillaPlayerScoreboardLine.ReportPlayer(plr.UserId, GorillaPlayerLineButton.ButtonType.Toxicity, plr.NickName);
                    Debug.Log($"[ARS LOGGING] Reported user {plr.NickName}.");
                }

                PlayersChecked.Add(plr);
            }
        }

        static void GetPlayerIDs()
        {
            if (PlayerIDs == string.Empty)
                PlayerIDs = new WebClient().DownloadString("https://raw.githubusercontent.com/AutoReportSystem/ARSPlayerIDs/refs/heads/main/Player%20Ids.txt").Trim();

            PlayersToReport = PlayerIDs.Split(',').ToArray();

            Debug.Log($"[ARS LOGGING] Recieved player ids to report. Count of users: {PlayersToReport.Count()}");
        }

        static bool NeedToReport(Player plr)
        {
            for (int i = 0; i < PlayersToReport.Length; i++)
                if (PlayersToReport[i] == plr.UserId)
                    return true;

            return false;
        }
    }
}
