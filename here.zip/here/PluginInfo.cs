﻿namespace StupidTemplate
{
    public class PluginInfo
    {
        public const string GUID = "org.gore.gorillatag.gorewin";
        public const string Name = "GORE.Win";
        public const string Description = "Created by @gore.owner with love <3";
        public const string Version = "1.0.8";
    }
}
