﻿using BepInEx;
using StupidTemplate.Menu;
using System.ComponentModel;
using System.IO;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace StupidTemplate.Patches.Internal
{
    [Description(PluginInfo.Description)]
    [BepInPlugin(PluginInfo.GUID, PluginInfo.Name, PluginInfo.Version)]
    public class HarmonyPatches : BaseUnityPlugin
    {
        private void OnEnable()
        {
            Menu.ApplyHarmonyPatches();
        }
        public static void text()
        {
            GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/motdHeadingText").GetComponent<TextMeshPro>().text = "GORE.Win"; /// MOTD heading
            GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/motdBodyText").GetComponent<TextMeshPro>().text = "\nGORE.Win\nA good mod menu for simple modders. I'm not responsible for any bans."; /// MOTD body
            GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/CodeOfConductHeadingText").GetComponent<TextMeshPro>().text = "GORE.Win \n----------------------------- \n"; /// COC heading
            GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/COCBodyText_TitleData").GetComponent<TextMeshPro>().text = "Made by GORE, GORE.Win | Ping: {PhotonNetwork.GetPing()} | Region: {PhotonNetwork.CloudRegion}\\"; /// COC body
        }

        private void OnDisable()
        {
            Menu.RemoveHarmonyPatches();
        }
    }
}
